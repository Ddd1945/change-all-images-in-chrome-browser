var intervalId = window.setInterval(function(){

var images = document.getElementsByTagName('img')

for (elt of images){
   elt.src = `${yandex.runtime.getURL("blackLord.jpg")}`
}

}, 1500);